build
```
$ ./gradlew installDist
```

run
```
$ ./build/install/examples/bin/ycsb-leveldb-client
```

java file is here : src/main/java/io/grpc/ycsb_leveldb/YCSBLevelDBClient.java
